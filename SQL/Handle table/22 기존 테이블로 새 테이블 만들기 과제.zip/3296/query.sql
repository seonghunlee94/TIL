# 이 곳에 정답을 작성해주세요 

CREATE TABLE beta_review_20s LIKE beta_review;
INSERT INTO beta_review_20s SELECT * FROM beta_review WHERE age >=20 and age <30;

# 체점용 코드
SELECT * FROM beta_review_20s;
# DESC beta_review_20s;