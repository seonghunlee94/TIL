CREATE TABLE beta_review(
id INT NOT NULL AUTO_INCREMENT,
email VARCHAR(40) NOT NULL,
age INT NOT NULL,
comment VARCHAR(80) NOT NULL,
PRIMARY KEY(id)
);



INSERT INTO beta_review (email, age, comment) VALUES ( 'dodoit@navez.com' , 27 , '앱 디자인이 간단해서 보기가 좋네요.');
INSERT INTO beta_review (email, age, comment) VALUES ( 'mykidlove@hanmain.net' , 30 , '왜 제 폰에서는 실행되자마자 꺼질까요 ㅜㅜ' );
INSERT INTO beta_review (email, age, comment) VALUES ( 'goshoppingMan111@gogle.com' , 40 , '애니메이션이 너무 이뻐요 ^^! 쇼핑하고픈 욕구가 마구 생겨요~' );
INSERT INTO beta_review (email, age, comment) VALUES ( 'realfashion@gogle.com' , 42 , '주문 창이 너무 늦게 뜨는 것 같아요, 해결해주세요');
INSERT INTO beta_review (email, age, comment) VALUES ( 'salespot@navzr.com' , 35 , '오 이 앱 나오면 앞으로 여기꺼만 써야지~' );
INSERT INTO beta_review (email, age, comment) VALUES ( 'programFun@codeit.kr' , 46 , '간혹 버벅거릴 때가 있는 것 빼고는 쓸만한 듯');
INSERT INTO beta_review (email, age, comment) VALUES ( 'GOALmania@navez.com' , 25 , '물품 분류가 좀더 세분화되면 좋을 것 같네요' );
INSERT INTO beta_review (email, age, comment) VALUES ( 'haleyhaley123@codeit.kr' , 19 , '이거 필터 아이콘 UI가 너무 이쁘네요 ㅋㅋ, 디자이너 짱');
INSERT INTO beta_review (email, age, comment) VALUES ( 'gotCHAgood!#@navez.com' , 27 , '흠.. 왜 내 껀 켜자마자 꺼져버리지');
INSERT INTO beta_review (email, age, comment) VALUES ( 'orilly@23@daun.net' , 33 , '사용성 엄청 좋네.. 역시 코팡, 정식 출시되면 믿고 쇼핑하겠습니다~!' );